<?php declare(strict_types = 1);

namespace Modules\TrendsReport;

use APP,
CMenuItem;

/**
 * 趋势报表模块 - 在报表(Reports)菜单下展示最近一天前端脚本生成的 vCenter 日巡检报表(HTML)
 */
trait ModuleInitTrait {

public function init(): void {
// Zabbix 7.0 顶级菜单 "Reports"(报表)
APP::Component()->get('menu.main')
->findOrAdd(_('Reports'))
->getSubmenu()
->insertAfter(_('Scheduled reports'),
(new CMenuItem(_('趋势报表')))
->setAction('trendsreport')
);
}
}

// Compatibility: Zabbix 6.4+ uses Zabbix\Core\CModule, Zabbix 6.0 uses Core\CModule
if (class_exists('Zabbix\\Core\\CModule', false)) {
class Module extends \Zabbix\Core\CModule {
use ModuleInitTrait;
}
} else {
class Module extends \Core\CModule {
use ModuleInitTrait;
}
}
