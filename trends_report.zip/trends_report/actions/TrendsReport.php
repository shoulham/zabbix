<?php declare(strict_types = 0);

namespace Modules\TrendsReport\Actions;

use CController,
CControllerResponseData;

class TrendsReport extends CController {

public function init(): void {
$this->disableCsrfValidation();
}

protected function checkInput(): bool {
$fields = [
'date' => 'string'
];
$ret = $this->validateInput($fields);
return $ret;
}

protected function checkPermissions(): bool {
return true;
}

protected function doAction(): void {
$report_dir = '/usr/share/zabbix/reports';
$selected_date = (string) $this->getInput('date', '');

// 扫描目录，收集所有日期存档文件（zabbix_report_YYYY-MM-DD.html），按日期倒序
$dates = [];
if (is_dir($report_dir)) {
$files = scandir($report_dir);
if ($files !== false) {
foreach ($files as $f) {
if (preg_match('/^zabbix_report_(\d{4}-\d{2}-\d{2})\.html$/', $f, $m)) {
$dates[$m[1]] = $f;
}
}
}
}
krsort($dates); // 最新日期在前

// 确定要展示的日期：优先用户选择的，否则取最新
$target = $selected_date;
if ($target === '' || !isset($dates[$target])) {
$target = array_key_first($dates);
}

$html = '';
$mtime = null;
$error = null;

if ($target !== null) {
// 展示该日期的存档
$rp = $report_dir . '/' . $dates[$target];
if (is_file($rp) && is_readable($rp)) {
$html = file_get_contents($rp);
$mtime = filemtime($rp);
}
else {
$error = _('报表文件不存在或不可读');
}
}
else {
// 没有任何存档，尝试读取固定最新文件
$rp = $report_dir . '/zabbix_report.html';
if (is_file($rp) && is_readable($rp)) {
$html = file_get_contents($rp);
$mtime = filemtime($rp);
$target = date('Y-m-d', (int)$mtime);
}
else {
$error = _('未找到任何报表文件，请确认日报脚本已运行并生成报表');
}
}

$data = [
'dates' => array_keys($dates),
'selected_date' => (string) $target,
'report_html' => (string) $html,
'report_mtime' => $mtime,
'error' => $error
];

$response = new CControllerResponseData($data);
$response->setTitle(_('趋势报表'));
$this->setResponse($response);
}
}
