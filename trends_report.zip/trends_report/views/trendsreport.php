<?php

/**
 * 趋势报表 - 视图
 * 展示某一天 py 脚本生成的 vCenter 日巡检报表 HTML，支持下拉选择日期（保留半个月）
 */

$dates = $data['dates'];           // 日期数组（倒序，最新在前）
$selected = $data['selected_date']; // 当前选中的日期
$html = $data['report_html'];
$mtime = $data['report_mtime'];
$error = $data['error'];

$wrap = (new \CDiv())->addClass('trends-report-wrap');

// 顶部工具栏：标题 + 日期下拉（原生 select，onchange 跳转）
$toolbar_html = '<div style="display:flex;align-items:center;gap:12px;margin-bottom:6px;">';
$toolbar_html .= '<span style="font-weight:bold;font-size:15px;">' . _('Zabbix vCenter 日巡检报表') . '</span>';
if ($dates) {
$toolbar_html .= '<select id="report_date" style="min-width:130px;" '
. 'onchange="location.href=\'zabbix.php?action=trendsreport&date=\' + this.value">';
foreach ($dates as $d) {
$sel = ($d === $selected) ? ' selected' : '';
$toolbar_html .= '<option value="' . $d . '"' . $sel . '>' . $d . '</option>';
}
$toolbar_html .= '</select>';
}
$toolbar_html .= '</div>';

echo $toolbar_html;

// 报表时间
if ($mtime) {
echo '<div style="color:#888;font-size:12px;margin-bottom:10px;">'
. _('报表时间: ') . date('Y-m-d H:i:s', (int)$mtime) . '</div>';
}

if ($error) {
echo '<div style="padding:15px;margin:10px 0;border-radius:4px;background:#fdf7f7;'
. 'border:1px solid #f5c6cb;color:#a94442;">' . $error . '</div>';
}
else {
echo '<iframe srcdoc="' . htmlspecialchars($html, ENT_QUOTES, 'UTF-8') . '" '
. 'style="width:100%;height:78vh;border:1px solid #ddd;border-radius:4px;background:#fff;" '
. 'scrolling="auto"></iframe>';
}

echo $wrap;
